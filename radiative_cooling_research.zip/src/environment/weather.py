"""Weather data loading (stub).
"""
import pandas as pd

def load_weather(csv_path):
    """Load weather CSV into pandas DataFrame."""
    return pd.read_csv(csv_path)
